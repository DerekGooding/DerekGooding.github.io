﻿function initializeAOS() {
    AOS.init();
}
